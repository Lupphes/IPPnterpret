from . import instructions
from . import ippcode
from . import parser
import logging

logging.getLogger(__name__).addHandler(logging.NullHandler())